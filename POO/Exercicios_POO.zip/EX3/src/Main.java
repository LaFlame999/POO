import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int A, B, C, D;
        int resultado1=0;
        int resultado2=0;
        int diferenca=0;

        System.out.println("Digite o valor dos números inteiros");
        Scanner sc = new Scanner(System.in);
        A = sc.nextInt();
        B = sc.nextInt();
        C = sc.nextInt();
        D = sc.nextInt();
        sc.close();
        resultado1 = A*B;
        resultado2 = C*D;
        diferenca = resultado1-resultado2;
        System.out.println("O resultado da diferença é: " + diferenca);
    }
}