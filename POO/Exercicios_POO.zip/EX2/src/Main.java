import java.util.Locale;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

        double raio;
        double pi = 3.14159;
        double area;
        Locale.setDefault(Locale.US);

        System.out.println("Digite o valor do raio da área");
        Scanner sc = new Scanner(System.in);
        raio = sc.nextDouble();
        sc.close();
        area = raio * raio * pi;
        System.out.printf("o valor da área é: %.4f\n", area);
    }
}