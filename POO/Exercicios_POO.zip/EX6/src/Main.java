import java.util.Scanner;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        double a, b, c;
        double area;
        double pi = 3.14159;

        System.out.println("Digite o valor de A ");
        Scanner sc = new Scanner(System.in);
        a = sc.nextDouble();
        System.out.println("Digite o valor de B ");
        b = sc.nextDouble();
        System.out.println("Digite o valor de C ");
        c = sc.nextDouble();
        sc.close();
        area = a*c/2;
        System.out.printf("Triangulo: %.3f\n", area);
        area = c*c*pi;
        System.out.printf("Circulo: %.3f\n", area);
        area = (a+b)*c/2;
        System.out.printf("Trapezio: %.3f\n", area);
        area = b*b;
        System.out.printf("Quadrado: %.3f\n", area);
        area = a*b;
        System.out.printf("Retangulo: %.3f\n", area);

    }
}