import java.util.Scanner;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        int cod1, cod2;
        int num1, num2;
        double value1, value2;
        double total;
        Locale.setDefault(Locale.US);

        System.out.println("Digite o código do produto 1");
        Scanner sc = new Scanner(System.in);
        cod1 = sc.nextInt();
        System.out.println("Digite o número de peças a serem compradas do produto 1");
        num1 = sc.nextInt();
        System.out.println("Digite o valor unitário do produto 1");
        value1 = sc.nextDouble();
        System.out.println("Digite o código do produto 2");
        cod2 = sc.nextInt();
        System.out.println("Digite o número de peças a serem compradas do produto 2");
        num2 = sc.nextInt();
        System.out.println("Digite o valor unitário do produto 2");
        value2 = sc.nextDouble();
        sc.close();
        total = value1*num1+value2*num2;
        System.out.printf("Valor a pagar: R$ %.2f\n", total);
    }
}