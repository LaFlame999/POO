import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int number;
        int hours;
        double salaryPerHour;
        double salary;
        Locale.setDefault(Locale.US);

        System.out.println("Digite o número do funcionário");
        Scanner sc = new Scanner(System.in);
        number = sc.nextInt();
        System.out.println("Digite as horas trabalhadas");
        hours = sc.nextInt();
        System.out.println("Digite o salário por hora do funcionário");
        salaryPerHour = sc.nextDouble();
        sc.close();
        salary = salaryPerHour * hours;
        System.out.printf("Número: %d\n", number);
        System.out.printf("Salário ganho: U$ %.2f\n", salary);
    }
}