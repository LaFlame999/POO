package EX1;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int x,y;
        int result = 0;
        System.out.println("digite os números que deseja somar");
        Scanner sc = new Scanner(System.in);
        x = sc.nextInt();
        y = sc.nextInt();
        sc.close();
        result = x+y;
        System.out.println("o resultado é: " + result);
    }
}